
var ping;

var radius = 120;
var x = 0;
var speed = 6.0;
var direction = 1;

function preload() {
	ping = loadSound("Ping.wav");
}

function setup() {
	createCanvas(440, 440);
	ellipseMode(RADIUS);
	x = width/2;
}


function draw() {
	background('purple');

	x += speed * direction;

	if ((x > width-radius) || (x < radius)) {

		direction = -direction;
		ping.play();

	}

	if (direction == 1) {
		arc(x, 220, radius, radius, 1.52, 5.76);
	} else {
		arc(x, 220, radius, radius, 2.67, 6.9);
	}
}