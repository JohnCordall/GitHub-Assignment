
var capture;

function setup() {
	createCanvas(480, 320);
	capture = createCapture(VIDEO);
	capture.size(400, 300);
}


function draw() {
	
	var aspectRatio = capture.height/capture.width;
	var h = width * aspectRatio;
	image(capture, 0, 0, width, h);
	filter(INVERT);

}