
var mic;
var amp;

var s;

function setup() {

	createCanvas(440, 440);

	background(0);
	
	mic = new p5.AudioIn();
	mic.start();

	amp = new p5.Amplitude();
	amp.setInput(mic);

}


function draw() {

	noStroke();
	fill(0, 10);
	rect(0, 0, width, height);

	s = map(amp.getLevel(), 0, 1.0, 10, width);
	fill(255);
	rect(width/2, height/2, s, s);
}