
var img1;
var img2;
var img3;

function preload() {

	img1 = loadImage("videogameimg.jpg");
	img2 = loadImage("videogameimg2.jpg");
	img3 = loadImage("videogameimg3.jpg");


}

function setup () {

	createCanvas(480, 420);

}

function draw () {

	image(img1, -120, 0);

	image(img2, -10, 0, 200, 100);

	image(img2, 300, 320, 200, 100);

	image(img3, 100, 0, mouseX * 2, mouseY * 2);
}