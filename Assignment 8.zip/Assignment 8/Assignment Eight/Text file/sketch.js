

function setup() {

	createCanvas(480, 120);

	textFont("Pacifico");

}


function draw () {

	background('red');

	textSize(30);

	text("This is my favorite shop...", 25, 60);

	textSize(15);

	text("on the citadel.", 27, 90);

}