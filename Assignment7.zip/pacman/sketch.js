//array
var x = [];



function setup() {

	createCanvas(440, 410);

	noStroke();

	fill(0);

	for (var i = 0; i < 3000; i++) {

		//for loop
		x[i] = random(-1000, 200); 

	}

}

function draw() {

	background(0);
	fill(255);
	rect(0, 100, width, 5);
	rect(0, 200, width, 5);
	rect(0, 300, width, 5);
	rect(0, 400, width, 5);

	//for loop ends
	for (var i = 0; i < x.length; i++) {

		//x-axis velocity
		x[i] +=0.5;

		//y-axis position
		var y = i * 0.4;

		//arc pacman
		arc(x[i], y, 12, 12, 0.52, 5.76);
		fill('yellow');
 

  
	}

}